var plotGraph = function(data){
  chartData = data;
  var svgContainer = d3.select('#svgContent');
 
  var boundaries = [70, 140, 220, 310, 400];

  var labelRadii = [60, 130, 210, 300, 390];

  var labelNames = {
   // '60': 'Very Similar',
    '130': ' Very Familiar',
    '210': 'Familiar',
    '300': 'Different',
    '390': 'Extremely Different'
  };

  attributeList = [
    'Batch',
    'Name',
    'Gender',
    'Discipline',
    'Marital Status',
    'Campus',
    'Associated Places',
    'Qualifications',
    'Associated Companies',
    'Faculty',
    'Languages'
  ];

  var boundaryCircles = svgContainer.selectAll("circle")
                            .data(boundaries)
                            .enter()
                            .append("circle");
  var circleAttributes = boundaryCircles
                          .attr("cx", 400)
                          .attr("cy", 400)
                          .attr("r", function(d) {return d; })
                          .style("fill-opacity", 0)
                          .style("stroke", "#262626")
                          .style("stroke-width", "2.5");

  $.each(chartData, function(index, node){
    var color = "hsl(" + node.hue + "," + node.saturation + "%, 70%)";
    var circles = svgContainer.append("circle")
                                      .attr("cx", node.xCoordinate)
                                      .attr("cy", node.yCoordinate)
                                      .attr("r", node.radius/8)
                                      .attr("id", node.uniqueID)
                                      .attr("class", "userCircle")
                                      .attr("nodeNumber", index)
                                      .style("fill", color)
                                      .style("fill-opacity", 0.75)
                                      .append("svg:title").text(node.name);
    }
  );
  var centerCircle = svgContainer.append("circle")
                                      .attr("cx", 400)
                                      .attr("cy", 400)
                                      .attr("r", 15)
                                      .attr("id", "circleCenter")
                                      .style("fill", "red")
                                      .style("fill-opacity", 0.45)
                                      .append("svg:title").text("You");

  $.each(labelRadii, function(idx, val){
    
    var curveStr = "M 400,400 m -" + val +",0 a " + val + "," + val + " 0 1,0 " + val*2 + ",0";
    var curveID = "curve" + val;
    svgContainer.append("defs").append("path")
        .attr("id", curveID)
        .attr("d", curveStr);
    
    var thingID = "thing" + val;
    var thing = svgContainer.append("g")
        .attr("id", thingID)
        .style("fill", "#d9d9d9");

    var curveSelect = "#" + curveID;
    thing.append("text")
        .style("font-size", "11px")
        .append("textPath")
        .attr("xlink:href", curveSelect)
        .text(labelNames[val]);

  });   

} //plotGraph

var applyFilter = function(filterData) {
  $.each(chartData, function(index, node){
    allTrue = true;
    $.each(filterData, function(filterKey, filterVal){
        if(typeof(node.allAttributes[filterVal]) === "undefined"){
          allTrue = false;
          return true;
        }
    });
    if(allTrue){
      randomAngle = Math.floor((Math.random()*360)+1);
      angleInRadians = randomAngle * (Math.PI/180);
      xAxis = 400 + Math.floor((400-node.radius) * Math.cos(angleInRadians));
      yAxis = 400 + Math.floor((400-node.radius) * Math.sin(angleInRadians));
     
      currentID = "#" + node.uniqueID;
      $(currentID).show();
      currentCircle = d3.select(currentID)
                        .transition()
                        .attr("cx", xAxis)
                        .attr("cy", yAxis)
                        .style("fill-opacity", 0.75)
                        .duration(600)
                        .delay(800);

    }
    else {
      currentID = "#" + node.uniqueID;
      //currentCircle = d3.select(currentID).transition().style("fill-opacity", 0).duration(800);
      currentCircle = d3.select(currentID).transition().style("fill-opacity", 0).duration(800);
      $(currentID).hide(800);
    }
  });

}

var createCircleFancybox = function(){
  $('.userCircle').click(function(){
    var nodeNumber = (this.attributes['nodeNumber']).value; 
    var person = chartData[nodeNumber];
    var displayStr = "<h3>" + person.name + "</h3>";
    var count = 0;
    $.each(person.allAttributes, function(key, val){
      // 1 because, it is name and we already display it
      if(count !== 1) {
        displayStr = displayStr + "<p>" + attributeList[count] + ": " + key + " </p>";
      }
      count++;
    }); 
    $.fancybox(
      displayStr,
      {
        'autoDimensions'  : false,
        'width'             : 350,
        'height'            : 'auto',
        'transitionIn'    : 'none',
        'transitionOut'   : 'none'
      }
    ); //fancybox
  }); //clickEvent
}
$(document).ready(function(){
  $.ajax({
    url : 'populatedata.php',
    dataType: 'json',
    success: function(data){
      plotGraph(data); 
      createCircleFancybox();
    }
  });

  //$('select').chosen();

  $('#filterButton').click(function(){
    var $inputs = $('#filterForm :input');

    var values = {};
    
    $inputs.each(function() {
        if($(this).attr("type") === "checkbox" || $(this).attr("type") === "radio" ){
          if($(this).is(":checked")){
            values[this.name.toLowerCase()] = $(this).attr("value").toLowerCase();
          }
        }
       else {
        if($(this).val() !== "")
          values[this.name.toLowerCase()] = $(this).val().toLowerCase();
      }
    });
    delete values[""];
    applyFilter(values);
  }); //filter button click event

  $('#clearButton').click(function(){
    $form = $("#filterForm");
    $form.find('input:text, input:password, input:file, select, textarea').val('');
    $form.find('input:radio, input:checkbox').removeAttr('checked').removeAttr('selected'); 
  });

});
