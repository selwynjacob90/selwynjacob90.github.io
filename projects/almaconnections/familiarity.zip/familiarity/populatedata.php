<?php

function createSampleUser() {
  $sampleUser = array(
  'Samuel',
  'Male',
  'Product Design',
  '2011',
  'Single',
  'Bangalore',
  'Hyderabad',
  'PGDPD',
  'Google',
  'Communication Design',
  'Telugu'
  );

  return $sampleUser;
}

function processData() {
  $sampleUser= createSampleUser();
  $result = array();
  $row = 1; 
  
  if (($csvFile = fopen("data.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($csvFile, 1000, ",")) !== FALSE) {
      $num_of_fields = count($data);
      $familiarityIndex = 0;
      $attrArray = array();        
      $row++;

      for ($i=0; $i < $num_of_fields; $i++) {
        if($i == '7' || $i == '8' || $i == '9' || $i == '11'){
          $items = explode(",", strtolower($data[$i]));
          $userItems = explode(",", strtolower($sampleUser[$i]));
          foreach ($userItems as $currentItem) {
            if(in_array($currentItem, $items)){
              $familiarityIndex += 40;
            }
            //array_push($attrArray, array(
            //    strtolower($currentItem) => 'true'
            //));
            foreach ($items as $givenItem) {
              $attrArray[strtolower($givenItem)] = "true";  
            }
              
          }
          continue; 
        }

        if(strcasecmp($sampleUser[$i], $data[$i]) == 0){
          $familiarityIndex += 60;
        }
/*        array_push($attrArray, array(
            strtolower($data[$i]) => 'true'
        ));
*/      $attrArray[strtolower($data[$i])] = "true";
      }//for

      $randomAngle = rand(1, 360);
      $angleRadians = deg2rad($randomAngle);
      $xCoordinate = (int) (400-$familiarityIndex) * cos($angleRadians);
      $yCoordinate = (int) (400-$familiarityIndex) * sin($angleRadians);
      $uniqueID = "circle" . rand() ;
      
      array_push($result, array(
        'name' => strtolower($data[0]),
        'radius' => $familiarityIndex,
        'xCoordinate' => 400 + $xCoordinate,
        'yCoordinate' => 400 + $yCoordinate,
        'hue' => 185 + ($familiarityIndex/6),
        'saturation' => 15 + ($familiarityIndex),
        'uniqueID' => $uniqueID,
        'allAttributes' => $attrArray
      ));

    }//while
    fclose($csvFile);
  }//if
  echo json_encode($result);
}

processData()
?>
